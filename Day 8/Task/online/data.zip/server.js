// Express Server Entry Point
const express = require('express');
const { loadTasks, loadUsers, saveTasks } = require('./bouns');

const app = express();
const PORT = 6060;

// Local Database
const tasks = [];
const users = [];

loadTasks(tasks, "data/tasks.json");
loadUsers(users, "data/users.json");

// Middleware
app.use(express.json());

// Routes
app.get('/api/tasks', (req, res) => {
    // should get all tasks from tasks array
});

app.get('/api/tasks/search', (req, res) => {
    // query string should contain keyword and we should search in tasks array using this keyword
    // If the keyword exists on title or description we should respond with this task
});

app.post('/api/tasks', (req, res) => {
    // body should contain these info title, description, priority(high, low, medium)

    // KEEP THIS CODE AFTER ADDING TASK TO TASKS ARRAY
    saveTasks(tasks, "data/tasks.json");
});

app.get("/profile", (req, res)  => {
    // we get query string from req and search user in users array
});

app.post("/register", (req, res)  => {
    // body should contain these info username, email, password

    // KEEP THIS CODE AFTER ADDING USER TO USERS ARRAY
    saveTasks(users, "data/users.json");
});

app.post("/login", (req, res)  => {
    // body should contain these info username or email, password
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
