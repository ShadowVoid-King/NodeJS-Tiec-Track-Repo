let  sumTwoNumbers = (a, b) => a + b;


module.exports = sumTwoNumbers